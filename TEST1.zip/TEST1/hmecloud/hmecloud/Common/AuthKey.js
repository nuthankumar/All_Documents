module.exports = {
  'secret': 'supersecret'
}
