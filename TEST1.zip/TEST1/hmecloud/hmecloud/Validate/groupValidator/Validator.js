//  const validate = require('validator')

/**
 * Service to provide list of all groups
 * Rules : check accountId &
 */
